# Masteran Burung Jawara

Proyek Android awal berbasis Kotlin dan Jetpack Compose.

## Build
Proyek ini menggunakan Android Gradle Plugin 8.6.1, Kotlin 2.0.21, dan Java 17.

## Catatan
Ini adalah kerangka aplikasi awal. Rekaman suara burung, katalog streaming, unduhan offline, favorit permanen, playlist, dan kontrol pemutaran latar belakang belum diimplementasikan. Tambahkan rekaman yang dimiliki atau memiliki izin distribusi sebelum merilis aplikasi.
