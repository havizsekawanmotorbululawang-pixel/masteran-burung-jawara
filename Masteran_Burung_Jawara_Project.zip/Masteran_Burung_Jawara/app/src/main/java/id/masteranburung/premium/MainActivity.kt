package id.masteranburung.premium

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Forest = Color(0xFF10251D)
private val CardGreen = Color(0xFF1C3A2D)
private val Gold = Color(0xFFE2B95B)
private val Cream = Color(0xFFF4F0E4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MasteranApp() }
    }
}

@Composable
fun MasteranApp() {
    val categories = listOf(
        "Murai Batu", "Kacer", "Cucak Ijo", "Kenari",
        "Lovebird", "Cendet", "Anis Merah", "Pleci",
        "Kolibri", "Jalak", "Cililin", " kapas Tembak"
    )
    var search by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("Murai Batu") }
    var favorite by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold,
        background = Forest,
        surface = CardGreen,
        onPrimary = Forest,
        onBackground = Cream,
        onSurface = Cream
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Forest) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(18.dp)
            ) {
                Text("MASTERAN", color = Gold, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("BURUNG JAWARA", color = Cream, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                Text("Teman latihan kicau harian", color = Cream.copy(alpha = .7f), fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))

                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Cari jenis burung...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Cream,
                        unfocusedTextColor = Cream,
                        focusedBorderColor = Gold,
                        unfocusedBorderColor = Cream.copy(alpha = .3f),
                        focusedLeadingIconColor = Gold,
                        unfocusedLeadingIconColor = Cream
                    )
                )
                Spacer(Modifier.height(18.dp))
                Text("PILIH MASTERAN", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(10.dp))

                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(categories.filter { it.contains(search, ignoreCase = true) }) { item ->
                        Card(
                            onClick = { selected = item },
                            colors = CardDefaults.cardColors(
                                containerColor = if (selected == item) Gold else CardGreen
                            ),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text("♫", color = if (selected == item) Forest else Gold, fontSize = 24.sp)
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    item,
                                    color = if (selected == item) Forest else Cream,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    if (selected == item) "Dipilih" else "Koleksi audio",
                                    color = if (selected == item) Forest.copy(alpha = .7f) else Cream.copy(alpha = .6f),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = CardGreen),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Pilihan masteran", color = Cream.copy(alpha = .7f), fontSize = 12.sp)
                                Text(selected, color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }
                            IconButton(onClick = { favorite = !favorite }) {
                                Icon(
                                    Icons.Default.Favorite,
                                    contentDescription = "Favorit",
                                    tint = if (favorite) Gold else Cream.copy(alpha = .5f)
                                )
                            }
                        }
                        Text(
                            "Koleksi rekaman masteran akan tersedia setelah audio resmi ditambahkan.",
                            color = Cream.copy(alpha = .75f),
                            fontSize = 12.sp
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Versi awal • Gratis • Online & offline menyusul",
                    color = Cream.copy(alpha = .45f),
                    fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
            }
        }
    }
}
